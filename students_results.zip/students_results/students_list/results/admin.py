from django.contrib import admin
from .models import Student_Registration,Affiliate_Staff_Registration,Under_affiliate_staff_registration,StudentResults,Subjects,SupplimentaryExamRequests,ReEvaluationRequests,Authentication

admin.site.register(Student_Registration)
admin.site.register(Affiliate_Staff_Registration)
admin.site.register(Under_affiliate_staff_registration)
admin.site.register(StudentResults)
admin.site.register(Subjects)
admin.site.register(SupplimentaryExamRequests)
admin.site.register(ReEvaluationRequests)
admin.site.register(Authentication)


