from django.shortcuts import render
from .models import Student_Registration,Affiliate_Staff_Registration,Under_affiliate_staff_registration
from .serializers import StudentRegistrationSerializer,AffiliateStaffRegistrationSerializer,UnderAffiliateStaffSerializer
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status

class AllRegistrationsView(APIView):
    def post(self,request,*args,**kwargs):
        try:
            user_type = request.data.get('user_type')
            if not user_type:
                return Response({"Error":"Enter user_type where student,affiliated_staff,under_affiliated_staff"},status=status.HTTP_400_BAD_REQUEST)
            if user_type == "student":
                email = request.data.get('email')
                date_of_birth = request.data.get('date_of_birth')
                if Student_Registration.objects.filter(email=email).exists():
                    return Response({"error": "Email already exists."}, status=status.HTTP_400_BAD_REQUEST)        
                serializer_object = StudentRegistrationSerializer(data=request.data)
                if serializer_object.is_valid(raise_exception=True):
                    reg_saved = serializer_object.save()
                    return Response({"success":"Student_Registration '{}' reistered succesfully".format(reg_saved.first_name)})
                return Response(serializer_object.errors,status=status.HTTP_400_BAD_REQUEST)
            
            elif user_type == "affiliated_staff":
                email = request.data.get('email')
                
                if Affiliate_Staff_Registration.objects.filter(email=email).exists():
                    return Response({"error": "Email already exists."}, status=status.HTTP_400_BAD_REQUEST)        
                serializer_object = AffiliateStaffRegistrationSerializer(data=request.data)
                if serializer_object.is_valid(raise_exception=True):
                    reg_saved = serializer_object.save()
                    return Response({"success":"Affiliate_Staff_Registration '{}' reistered succesfully".format(reg_saved.first_name)})
                return Response(serializer_object.errors,status=status.HTTP_400_BAD_REQUEST)
            
            elif user_type == "under_affiliated_staff":
                email = request.data.get('email')
                
                if Under_affiliate_staff_registration.objects.filter(email=email).exists():
                    return Response({"error": "Email already exists."}, status=status.HTTP_400_BAD_REQUEST)        
                serializer_object = UnderAffiliateStaffSerializer(data=request.data)
                if serializer_object.is_valid(raise_exception=True):
                    reg_saved = serializer_object.save()
                    return Response({"success":"Under_affiliate_staff_registration '{}' reistered succesfully".format(reg_saved.first_name)})
                return Response(serializer_object.errors,status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            return Response({"error":"An unexpected error occured"},status=status.HTTP_500_INTERNAL_SERVER_ERROR)


             