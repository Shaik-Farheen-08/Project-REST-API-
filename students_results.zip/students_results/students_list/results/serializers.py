from .models import Authentication,Student_Registration,Affiliate_Staff_Registration,Under_affiliate_staff_registration
from rest_framework import serializers
class AuthSerializer(serializers.ModelSerializer):
    class Meta:
        model = Authentication
        fields = '__all__'

class StudentRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student_Registration
        fields = '__all__'
        

class AffiliateStaffRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Affiliate_Staff_Registration
        fields = '__all__'

class UnderAffiliateStaffSerializer(serializers.ModelSerializer):
    class Meta:
        model = Under_affiliate_staff_registration
        fields = '__all__'

