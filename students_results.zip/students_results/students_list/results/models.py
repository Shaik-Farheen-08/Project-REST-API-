from django.db import models
    
class Student_Registration(models.Model):
    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=60)
    email = models.EmailField(max_length=60)
    course_name = models.CharField(max_length=60)
    registration_date = models.DateField()
   
    

class Affiliate_Staff_Registration(models.Model):

    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60) 
    email = models.EmailField(null=True,blank=True)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=60)
    department = models.CharField(max_length=60)
    role = models.CharField(max_length=60)

    
class Under_affiliate_staff_registration(models.Model):
    first_name = models.CharField(max_length=60)
    last_name = models.CharField(max_length=60)
    email = models.EmailField(null=True,blank=True)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=60)
    department = models.CharField(max_length=60)
    role = models.CharField(max_length=60)

    

class StudentResults(models.Model):
    student_name = models.CharField(max_length=60)
    student_id = models.IntegerField()
    subject_id = models.IntegerField()
    marks = models.IntegerField()
    average_grade = models.FloatField()
    result_status= models.CharField(max_length=60)

class Subjects(models.Model):
    subject_id = models.IntegerField()
    subject_name = models.CharField(max_length=60)

class SupplimentaryExamRequests(models.Model):
    request_id = models.IntegerField()
    student_id = models.IntegerField()
    subject_id = models.IntegerField()
    exam_date = models.DateField()
    status = models.CharField(max_length=60)

class ReEvaluationRequests(models.Model):
    request_id = models.IntegerField()
    student_id = models.IntegerField()
    subject_id = models.IntegerField()
    original_score = models.IntegerField()
    re_evaluated_score = models.IntegerField()
    status = models.IntegerField()

class Authentication(models.Model):
    user_id = models.IntegerField()
    role = models.CharField(max_length=60)
    password = models.IntegerField()
